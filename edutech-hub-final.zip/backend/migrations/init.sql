-- Init schema for EduTech Hub (Postgres)
CREATE TABLE IF NOT EXISTS contacts (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  message TEXT,
  ts TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS enrolls (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  course TEXT,
  ts TIMESTAMP DEFAULT now()
);
