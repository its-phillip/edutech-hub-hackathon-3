const express = require('express');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const app = express();
const DATA_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend', 'dist')));

// Initialize JSON fallback storage
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({ contacts: [], enrolls: [] }, null, 2));

// Postgres connection (optional). If DATABASE_URL is set, we use Postgres and create tables if necessary.
let pool = null;
async function initDb() {
  const DATABASE_URL = process.env.DATABASE_URL || null;
  if (!DATABASE_URL) return;
  pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false });
  // create tables if not exist
  await pool.query(`CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    name TEXT,
    email TEXT,
    message TEXT,
    ts TIMESTAMP
  );`);
  await pool.query(`CREATE TABLE IF NOT EXISTS enrolls (
    id SERIAL PRIMARY KEY,
    name TEXT,
    email TEXT,
    course TEXT,
    ts TIMESTAMP
  );`);
  console.log('Connected to Postgres and ensured tables exist.');
}

initDb().catch(err => {
  console.error('Failed to initialize Postgres:', err.message);
  pool = null;
});

app.post('/api/contact', async (req, res) => {
  try {
    if (pool) {
      await pool.query('INSERT INTO contacts(name,email,message,ts) VALUES($1,$2,$3,now())', [req.body.name, req.body.email, req.body.message]);
      return res.status(200).json({ ok: true, source: 'postgres' });
    } else {
      const d = JSON.parse(fs.readFileSync(DATA_FILE));
      d.contacts.push({ ...req.body, ts: new Date().toISOString() });
      fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
      return res.status(200).json({ ok: true, source: 'json' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false });
  }
});

app.post('/api/enroll', async (req, res) => {
  try {
    if (pool) {
      await pool.query('INSERT INTO enrolls(name,email,course,ts) VALUES($1,$2,$3,now())', [req.body.name, req.body.email, req.body.course || 'unknown']);
      return res.status(200).json({ ok: true, source: 'postgres' });
    } else {
      const d = JSON.parse(fs.readFileSync(DATA_FILE));
      d.enrolls.push({ ...req.body, ts: new Date().toISOString() });
      fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
      return res.status(200).json({ ok: true, source: 'json' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

// fallback to frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'dist', 'index.html'));
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('Server running on', port));
