const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

import React, { useEffect, useMemo, useState } from "react";

/* EduTech Hub — Award‑caliber single-file React app
   This is a single-file React app intended for Vite. Tailwind is configured in the project.
   Replace assets/logo.png with your actual logo extracted from the pitch deck.
*/

const categories = ["Programming", "Data Science", "UI/UX", "Business", "Cybersecurity"];

function classNames(...xs) {
  return xs.filter(Boolean).join(" ");
}

function useLocalStorage(key, initial) {
  const [state, setState] = useState(() => {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch {}
  }, [key, state]);
  return [state, setState];
}

const COURSES = [
  { id: "C1", title: "Foundations of Programming", category: "Programming", level: "Beginner", hours: 20, price: 0, rating: 4.7 },
  { id: "C2", title: "Practical Data Science", category: "Data Science", level: "Intermediate", hours: 36, price: 49, rating: 4.8 },
  { id: "C3", title: "UI/UX Essentials", category: "UI/UX", level: "Beginner", hours: 18, price: 29, rating: 4.6 },
  { id: "C4", title: "Intro to Cybersecurity", category: "Cybersecurity", level: "Beginner", hours: 24, price: 39, rating: 4.5 },
  { id: "C5", title: "Business for Tech", category: "Business", level: "Intermediate", hours: 16, price: 25, rating: 4.4 },
];

const FEATURES = [
  {
    title: "AI‑Powered Personalized Paths",
    desc: "Adaptive lesson sequencing that meets learners at their skill level and aligns with local curricula.",
  },
  { title: "Localized Curriculum", desc: "Content mapped to regional syllabuses and available in multiple languages." },
  { title: "Real‑time Progress & Teacher Dashboard", desc: "Insights for teachers and guardians to support learning interventions early." },
  { title: "Virtual Classrooms & Live Tutoring", desc: "Blend asynchronous materials with live support and cohort learning." },
];

const TESTIMONIALS = [
  { name: "Aisha K.", role: "Junior Data Analyst", quote: "The projects and local curriculum focus got me job-ready fast." },
  { name: "Brian O.", role: "Frontend Developer", quote: "Clear roadmaps and hands-on labs — excellent." },
];

const TEAM = [
  { name: "Phillip Onchiri", title: "Managing Director", email: "philliponchiri@gmail.com" },
  { name: "Phoebe Muriuki", title: "HR Manager", email: "phoebemuriuki0@gmail.com" },
];

export default function App() {
  const [dark, setDark] = useLocalStorage("ed:dark", true);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState("All");
  const [wish, setWish] = useLocalStorage("ed:wish", []);
  const [enroll, setEnroll] = useState(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", !!dark);
  }, [dark]);

  const visible = useMemo(() => {
    return COURSES.filter((c) => (cat === "All" ? true : c.category === cat)).filter((c) => c.title.toLowerCase().includes(query.toLowerCase()));
  }, [query, cat]);

  function toggleWish(id) {
    setWish((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  return (
    <div className={classNames("antialiased min-h-screen font-sans bg-gradient-to-br", dark ? "from-slate-900 via-slate-800 to-indigo-900 text-slate-100" : "from-white via-sky-50 to-white text-slate-900")}>
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/60 dark:bg-slate-900/60 border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/logo.png" alt="EduTech Hub" className="h-10 w-10 rounded-2xl object-cover" />
            <div>
              <div className="text-lg font-extrabold">EduTech Hub</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Localized • AI‑Personalized • Multilingual</div>
            </div>
          </div>
          <nav className="flex items-center gap-3 text-sm">
            <a href="#features" className="hover:underline">Features</a>
            <a href="#courses" className="hover:underline">Courses</a>
            <a href="#pricing" className="hover:underline">Pricing</a>
            <a href="#team" className="hover:underline">Team</a>
            <a href="#contact" className="ml-2 inline-flex items-center rounded-full bg-gradient-to-r from-sky-500 to-violet-600 px-3 py-1 text-white text-sm font-semibold">Get a Demo</a>
            <button onClick={() => setDark((d) => !d)} aria-label="Toggle theme" className="ml-3 p-1 rounded-md bg-white/30 dark:bg-slate-700/30">
              {dark ? '🌙' : '🔆'}
            </button>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Personalized learning for every student — <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-violet-400">aligned to your curriculum</span>.</h1>
            <p className="mt-4 text-lg text-slate-500 dark:text-slate-300">EduTech Hub combines AI-driven pathways, localized content, and multilingual support to increase engagement and learning outcomes for schools and learners.</p>

            <div className="mt-6 flex gap-3">
              <a href="#contact" className="inline-flex items-center gap-2 bg-gradient-to-r from-sky-500 to-violet-600 text-white px-5 py-3 rounded-md font-semibold shadow-lg">Request a Demo</a>
              <a href="#courses" className="inline-flex items-center gap-2 border border-slate-200 dark:border-slate-700 px-4 py-3 rounded-md">Explore Courses</a>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div className="p-4 bg-white/70 dark:bg-slate-800/60 rounded-lg shadow-sm">
                <div className="text-2xl font-bold">95%</div>
                <div className="text-xs text-slate-500">of targeted students exposed to tech</div>
              </div>
              <div className="p-4 bg-white/70 dark:bg-slate-800/60 rounded-lg shadow-sm">
                <div className="text-2xl font-bold">Localized</div>
                <div className="text-xs text-slate-500">Curriculum‑aligned content</div>
              </div>
              <div className="p-4 bg-white/70 dark:bg-slate-800/60 rounded-lg shadow-sm">
                <div className="text-2xl font-bold">AI‑Personalized</div>
                <div className="text-xs text-slate-500">Adaptive learning paths</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10">
              <img alt="EduTech interface" src="/assets/hero.svg" className="w-full h-auto" />
            </div>
            <div className="absolute -bottom-6 left-6 bg-white dark:bg-slate-800 rounded-xl p-4 shadow-lg border border-slate-100/40">
              <div className="text-sm text-slate-500">Pilot partnership</div>
              <div className="text-base font-semibold">Partner schools + NGOs</div>
            </div>
          </div>
        </section>

        <section className="mt-16 grid md:grid-cols-2 gap-10 items-start">
          <div className="p-6 bg-white/60 dark:bg-slate-800/60 rounded-2xl shadow">
            <h3 className="text-xl font-bold">The Problem</h3>
            <p className="mt-3 text-slate-600 dark:text-slate-300">Many platforms are generic and don’t reflect local syllabuses or languages. That causes disengagement, poor outcomes, and wasted time for students and teachers.</p>

            <ul className="mt-4 space-y-2 text-slate-600 dark:text-slate-300">
              <li>🔸 Content not aligned to regional curricula</li>
              <li>🔸 Language and cultural barriers to learning</li>
              <li>🔸 Lack of teacher visibility into student progress</li>
            </ul>
          </div>

          <div className="p-6 bg-white/60 dark:bg-slate-800/60 rounded-2xl shadow">
            <h3 className="text-xl font-bold">Our Solution</h3>
            <p className="mt-3 text-slate-600 dark:text-slate-300">EduTech Hub delivers localized, AI‑driven learning paths, interactive lessons, and multilingual support — built to integrate with school curricula and provide measurable outcomes.</p>

            <div className="mt-4 grid grid-cols-1 gap-3">
              {FEATURES.map((f) => (
                <div key={f.title} className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700 grid place-content-center">★</div>
                  <div>
                    <div className="font-semibold">{f.title}</div>
                    <div className="text-sm text-slate-500">{f.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="courses" className="mt-16">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Featured Courses</h2>
            <div className="flex items-center gap-3">
              <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-md p-2 bg-white/50 dark:bg-slate-800/50">
                <option>All</option>
                {categories.map((c) => <option key={c}>{c}</option>)}
              </select>
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search courses" className="px-3 py-2 rounded-md bg-white/50 dark:bg-slate-800/50" />
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {visible.map((c) => (
              <article key={c.id} className="bg-white/70 dark:bg-slate-800/60 rounded-2xl p-5 shadow hover:shadow-lg transition">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-lg">{c.title}</h3>
                    <div className="text-sm text-slate-500">{c.category} • {c.level}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold">{c.price === 0 ? 'Free' : '$' + c.price}</div>
                    <div className="text-xs text-slate-500">{c.hours} hrs</div>
                  </div>
                </div>

                <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">Practical, project‑led modules mapped to local learning objectives.</p>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button onClick={() => toggleWish(c.id)} className={classNames("px-3 py-1 rounded-md text-sm", wish.includes(c.id) ? 'bg-violet-600 text-white' : 'bg-white/30 dark:bg-slate-700/40')}>{wish.includes(c.id) ? 'Saved' : 'Save'}</button>
                    <button onClick={() => setEnroll(c)} className="px-3 py-1 rounded-md bg-gradient-to-r from-sky-500 to-violet-600 text-white text-sm">Enroll</button>
                  </div>
                  <div className="text-sm text-slate-500">⭐ {c.rating}</div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="pricing" className="mt-16">
          <h2 className="text-2xl font-bold">Pricing & Plans</h2>
          <p className="mt-2 text-slate-500">Subscription model for individuals, school licensing, and NGO partnerships. Needs‑based discounts available.</p>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800/60 shadow">
              <div className="text-sm font-semibold">Starter</div>
              <div className="text-3xl font-extrabold mt-2">Free</div>
              <div className="mt-3 text-sm text-slate-500">Access to core courses and AI assessments.</div>
              <ul className="mt-4 space-y-2 text-sm">
                <li>• Curriculum‑aligned courses</li>
                <li>• Personalized learning preview</li>
              </ul>
              <div className="mt-6">
                <button className="w-full px-4 py-2 rounded-md bg-gradient-to-r from-sky-500 to-violet-600 text-white font-semibold">Get started</button>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800/60 shadow border-2 border-violet-500">
              <div className="text-sm font-semibold">Pro</div>
              <div className="text-3xl font-extrabold mt-2">$29/mo</div>
              <div className="mt-3 text-sm text-slate-500">Full access to all courses, certificates, and live tutoring credits.</div>
              <ul className="mt-4 space-y-2 text-sm">
                <li>• Full AI pathways</li>
                <li>• Teacher dashboards</li>
              </ul>
              <div className="mt-6">
                <button className="w-full px-4 py-2 rounded-md bg-violet-600 text-white font-semibold">Choose Pro</button>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800/60 shadow">
              <div className="text-sm font-semibold">School</div>
              <div className="text-3xl font-extrabold mt-2">Contact us</div>
              <div className="mt-3 text-sm text-slate-500">Custom licensing, localized content creation, and pilot programs.</div>
              <ul className="mt-4 space-y-2 text-sm">
                <li>• Curriculum mapping</li>
                <li>• Pilot & training support</li>
              </ul>
              <div className="mt-6">
                <a href="#contact" className="w-full inline-block text-center px-4 py-2 rounded-md bg-white/30 dark:bg-slate-700/30 font-semibold">Request a quote</a>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-16 grid md:grid-cols-2 gap-8 items-start">
          <div>
            <h3 className="text-xl font-bold">Impact & Traction</h3>
            <p className="mt-3 text-slate-600 dark:text-slate-300">Pilot programs with partner schools for feedback and testimonials; strong uptake where content is localized and measurable.</p>
            <ul className="mt-4 text-sm text-slate-600 dark:text-slate-300 space-y-2">
              <li>• Pilot-ready curriculum packs</li>
              <li>• Partnerships with local NGOs and influencers</li>
              <li>• Focus on measurable learning outcomes</li>
            </ul>
          </div>
          <div className="space-y-4">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="p-4 bg-white/70 dark:bg-slate-800/60 rounded-xl shadow">
                <div className="font-semibold">{t.name} <span className="text-xs text-slate-500">• {t.role}</span></div>
                <div className="mt-2 text-sm text-slate-600 dark:text-slate-300">"{t.quote}"</div>
              </div>
            ))}
          </div>
        </section>

        <section id="team" className="mt-16">
          <h2 className="text-2xl font-bold">Team</h2>
          <p className="mt-2 text-slate-500">Core team focused on curriculum, product, and partnerships.</p>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {TEAM.map((m) => (
              <div key={m.name} className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800/60 shadow">
                <div className="h-20 w-20 rounded-xl bg-gradient-to-br from-sky-500 to-violet-600 grid place-content-center text-white font-bold">{m.name.split(' ')[0][0]}</div>
                <div className="mt-4 font-semibold">{m.name}</div>
                <div className="text-sm text-slate-500">{m.title}</div>
                <div className="mt-3 text-sm text-slate-600 dark:text-slate-300">Email: <a href={`mailto:${m.email}`} className="text-sky-600 dark:text-sky-400">{m.email}</a></div>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="mt-16 grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-bold">Frequently asked questions</h3>
            <div className="mt-4 space-y-4 text-sm text-slate-600 dark:text-slate-300">
              <div>
                <div className="font-semibold">Do students get certificates?</div>
                <div>Yes — certificates are issued on course completion and are shareable.</div>
              </div>
              <div>
                <div className="font-semibold">Are courses aligned to local curricula?</div>
                <div>Yes. We map content to regional syllabuses and can adapt on request.</div>
              </div>
              <div>
                <div className="font-semibold">Do you offer financial aid?</div>
                <div>We provide needs‑based discounts and school licensing to increase access.</div>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800/60 shadow">
            <h3 className="text-lg font-bold">Get in touch / Request a pilot</h3>
            <form className="mt-4 space-y-3" onSubmit={async (e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              const body = Object.fromEntries(fd.entries());
              try {
                const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
                if (res.ok) {
                  alert("Thanks — we will contact you soon!");
                  e.target.reset();
                } else {
                  alert("There was an error. Try again later.");
                }
              } catch (err) {
                console.error(err);
                alert("Network error — check console.");
              }
            }}>
              <div>
                <label className="text-sm">Name</label>
                <input name="name" required className="mt-1 w-full rounded-md p-2 bg-white/50 dark:bg-slate-700/40" />
              </div>
              <div>
                <label className="text-sm">Email</label>
                <input name="email" type="email" required className="mt-1 w-full rounded-md p-2 bg-white/50 dark:bg-slate-700/40" />
              </div>
              <div>
                <label className="text-sm">Message</label>
                <textarea name="message" rows={3} className="mt-1 w-full rounded-md p-2 bg-white/50 dark:bg-slate-700/40" defaultValue={"We're interested in a pilot for local schools..."} />
              </div>
              <div className="flex items-center gap-3">
                <button type="submit" className="px-4 py-2 rounded-md bg-gradient-to-r from-sky-500 to-violet-600 text-white font-semibold">Send request</button>
                <a href="mailto:philliponchiri@gmail.com" className="text-sm text-slate-500">Or email philliponchiri@gmail.com</a>
              </div>
            </form>
          </div>
        </section>

        <footer className="mt-20 py-10 text-sm text-slate-500">
          <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-6">
            <div>
              <div className="font-bold">EduTech Hub</div>
              <div className="mt-2">Personalized learning for every student — built for local curricula and languages.</div>
            </div>
            <div>
              <div className="font-semibold">Contact</div>
              <div className="mt-2">philliponchiri@gmail.com</div>
              <div>+254 796 261 778</div>
            </div>
            <div>
              <div className="font-semibold">Legal</div>
              <div className="mt-2">Privacy • Terms</div>
            </div>
          </div>
        </footer>
      </main>

      {enroll && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40">
          <div className="w-full max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 shadow-xl">
            <h3 className="text-xl font-bold">Enroll — {enroll.title}</h3>
            <p className="mt-2 text-sm text-slate-600">Enter your details and we'll send a welcome pack.</p>
            <form onSubmit={async (e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              const body = Object.fromEntries(fd.entries());
              try {
                const res = await fetch("/api/enroll", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
                if (res.ok) {
                  alert("Enrolled — check email");
                  setEnroll(null);
                } else {
                  alert("There was an error enrolling.");
                }
              } catch (err) {
                console.error(err);
                alert("Network error — check console.");
              }
            }} className="mt-4 space-y-3">
              <input name="name" placeholder="Your name" required className="w-full rounded-md p-2 bg-white/50 dark:bg-slate-700/40" />
              <input name="email" type="email" placeholder="Email" required className="w-full rounded-md p-2 bg-white/50 dark:bg-slate-700/40" />
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setEnroll(null)} className="px-4 py-2 rounded-md">Cancel</button>
                <button type="submit" className="px-4 py-2 rounded-md bg-gradient-to-r from-sky-500 to-violet-600 text-white">Confirm Enroll</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}